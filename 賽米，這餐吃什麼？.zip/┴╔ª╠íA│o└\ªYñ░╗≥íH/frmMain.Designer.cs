﻿namespace 賽米_這餐吃什麼_
{
    partial class frmMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.functionBar = new System.Windows.Forms.MenuStrip();
            this.應用ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新增店家ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改店家ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.刪除店家ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.令咒ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.忘卻所有一切ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblDialog = new System.Windows.Forms.Label();
            this.lblDialogName = new System.Windows.Forms.Label();
            this.imgSemiramis = new System.Windows.Forms.PictureBox();
            this.令賽米消氣ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.functionBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSemiramis)).BeginInit();
            this.SuspendLayout();
            // 
            // functionBar
            // 
            this.functionBar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.functionBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.應用ToolStripMenuItem,
            this.令咒ToolStripMenuItem});
            this.functionBar.Location = new System.Drawing.Point(0, 0);
            this.functionBar.Name = "functionBar";
            this.functionBar.Size = new System.Drawing.Size(771, 24);
            this.functionBar.TabIndex = 0;
            this.functionBar.Text = "fuctionBar";
            // 
            // 應用ToolStripMenuItem
            // 
            this.應用ToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.應用ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新增店家ToolStripMenuItem,
            this.修改店家ToolStripMenuItem,
            this.刪除店家ToolStripMenuItem});
            this.應用ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.應用ToolStripMenuItem.Name = "應用ToolStripMenuItem";
            this.應用ToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.應用ToolStripMenuItem.Text = "賽米的技能";
            // 
            // 新增店家ToolStripMenuItem
            // 
            this.新增店家ToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.新增店家ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.新增店家ToolStripMenuItem.Name = "新增店家ToolStripMenuItem";
            this.新增店家ToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.新增店家ToolStripMenuItem.Text = "記憶新的店家";
            this.新增店家ToolStripMenuItem.Click += new System.EventHandler(this.新增店家ToolStripMenuItem_Click);
            // 
            // 修改店家ToolStripMenuItem
            // 
            this.修改店家ToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.修改店家ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.修改店家ToolStripMenuItem.Name = "修改店家ToolStripMenuItem";
            this.修改店家ToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.修改店家ToolStripMenuItem.Text = "修改已被記憶的店家內容";
            this.修改店家ToolStripMenuItem.Click += new System.EventHandler(this.修改店家ToolStripMenuItem_Click);
            // 
            // 刪除店家ToolStripMenuItem
            // 
            this.刪除店家ToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.刪除店家ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.刪除店家ToolStripMenuItem.Name = "刪除店家ToolStripMenuItem";
            this.刪除店家ToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.刪除店家ToolStripMenuItem.Text = "忘掉不必要的店家";
            this.刪除店家ToolStripMenuItem.Click += new System.EventHandler(this.刪除店家ToolStripMenuItem_Click);
            // 
            // 令咒ToolStripMenuItem
            // 
            this.令咒ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.忘卻所有一切ToolStripMenuItem,
            this.令賽米消氣ToolStripMenuItem});
            this.令咒ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.令咒ToolStripMenuItem.Name = "令咒ToolStripMenuItem";
            this.令咒ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.令咒ToolStripMenuItem.Text = "令咒";
            // 
            // 忘卻所有一切ToolStripMenuItem
            // 
            this.忘卻所有一切ToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.忘卻所有一切ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.忘卻所有一切ToolStripMenuItem.Name = "忘卻所有一切ToolStripMenuItem";
            this.忘卻所有一切ToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.忘卻所有一切ToolStripMenuItem.Text = "忘卻所有一切";
            this.忘卻所有一切ToolStripMenuItem.Click += new System.EventHandler(this.忘卻所有一切ToolStripMenuItem_Click);
            // 
            // lblDialog
            // 
            this.lblDialog.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDialog.Font = new System.Drawing.Font("新細明體", 25F);
            this.lblDialog.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDialog.Location = new System.Drawing.Point(12, 402);
            this.lblDialog.Name = "lblDialog";
            this.lblDialog.Padding = new System.Windows.Forms.Padding(10);
            this.lblDialog.Size = new System.Drawing.Size(747, 175);
            this.lblDialog.TabIndex = 2;
            this.lblDialog.Click += new System.EventHandler(this.lblDialog_Click);
            // 
            // lblDialogName
            // 
            this.lblDialogName.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.lblDialogName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDialogName.Font = new System.Drawing.Font("新細明體", 20F);
            this.lblDialogName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDialogName.Location = new System.Drawing.Point(22, 358);
            this.lblDialogName.Name = "lblDialogName";
            this.lblDialogName.Size = new System.Drawing.Size(150, 32);
            this.lblDialogName.TabIndex = 3;
            this.lblDialogName.Text = "セミラミス";
            this.lblDialogName.Click += new System.EventHandler(this.lblDialog_Click);
            // 
            // imgSemiramis
            // 
            this.imgSemiramis.Location = new System.Drawing.Point(187, 31);
            this.imgSemiramis.Name = "imgSemiramis";
            this.imgSemiramis.Size = new System.Drawing.Size(402, 359);
            this.imgSemiramis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgSemiramis.TabIndex = 1;
            this.imgSemiramis.TabStop = false;
            this.imgSemiramis.Click += new System.EventHandler(this.lblDialog_Click);
            // 
            // 令賽米消氣ToolStripMenuItem
            // 
            this.令賽米消氣ToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlText;
            this.令賽米消氣ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Control;
            this.令賽米消氣ToolStripMenuItem.Name = "令賽米消氣ToolStripMenuItem";
            this.令賽米消氣ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.令賽米消氣ToolStripMenuItem.Text = "令賽米消氣";
            this.令賽米消氣ToolStripMenuItem.Click += new System.EventHandler(this.令賽米消氣ToolStripMenuItem_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(771, 586);
            this.Controls.Add(this.lblDialogName);
            this.Controls.Add(this.lblDialog);
            this.Controls.Add(this.imgSemiramis);
            this.Controls.Add(this.functionBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.functionBar;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMain";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "賽米，這餐吃什麼？2.0";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.functionBar.ResumeLayout(false);
            this.functionBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSemiramis)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip functionBar;
        private System.Windows.Forms.ToolStripMenuItem 應用ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新增店家ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改店家ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 刪除店家ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 令咒ToolStripMenuItem;
        private System.Windows.Forms.PictureBox imgSemiramis;
        private System.Windows.Forms.Label lblDialog;
        private System.Windows.Forms.ToolStripMenuItem 忘卻所有一切ToolStripMenuItem;
        private System.Windows.Forms.Label lblDialogName;
        private System.Windows.Forms.ToolStripMenuItem 令賽米消氣ToolStripMenuItem;
    }
}

